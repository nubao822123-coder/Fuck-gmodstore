-- [[ CRIADO POR ZOMBIE EXTINGUISHER ]]

local pt = {
	
	-- Estatísticas
	lag = "LAG",
	collisions = "COLISÕES",
	props = "PROPS",
	propsFrozen = "PROPS CONGELADOS",
	npcs = "NPCS",
	vehicles = "VEÍCULOS",
	players = "JOGADORES",
	uptime = "TEMPO DE ATIVIDADE",
	entities = "ENTIDADES",
	spawned = "SPAWNADAS",
	fps = "FPS",
	tickrate = "TICKRATE",
	toggleOverlay = "Alternar Sobreposição de Estatísticas",
	runAntiLagMeasures = "EXECUTAR MEDIDAS ANTI-LAG",
	startingUp = "Servidor iniciado!",
	shuttingDown = "Servidor desligando!",
	
	-- Usuários
	search = "Pesquisar",
	constraints = "RESTRIÇÕES",
	showEntities = "Mostrar Entidades",
	hideEntities = "Ocultar Entidades",
	resetMap = "Reiniciar Mapa",
	freezeEntities = "Congelar Entidades",
	removeEntities = "Remover Entidades",
	
	-- Global
	noCollideEntities = "Entidades Sem Colisão",
	
	-- Lag
	heavyLag = "Lag severo detectado!",
	lagIsStuck = "Aviso: lag está travado!",
	crashPrevented = "Queda do servidor evitada!",
	cleaningMap = "+ Limpando o mapa...",
	removingEnts = "+ Removendo %s entidades",
	revertChanges = "+ Removendo %s entidades criadas nos últimos %s minutos",
	freezeingEnts = "+ Congelando %s entidades",
	noCollidingEnts = "+ Removendo colisão de %s entidades",
	offenderWarning = "%s tem uma quantidade suspeita de entidades (%s) antes do lag!",
	freezingAllEntities = "Congelou todas as entidades (%s)",
	
	-- Dupes
	dupesNotEnabled = "Dupes não estão habilitados neste servidor!",
	advDupesNotEnabled = "Advanced Dupes não estão habilitados neste servidor!",
	dupeExceedsSize = "Esse dupe excede o limite máximo de tamanho! (tamanho:%s, máximo:%s)",
	dupeExceedsRopeLimit = "Esse dupe excede o limite máximo de cordas! (quantidade:%s, máximo:%s)",
	dupeInformation = "%s spawnando dupe contendo %s entidades e %s restrições",
	
	-- Notificações
	triggeredAntiLagMeasures = "ativou medidas anti-lag!",
	ranAntilagMeasures = "executou medidas anti-lag!",
	hasNoEntities = "não possui entidades!",
	youRemovedFrom = "Você removeu %s entidades de %s!",
	removedYourObjects = "removeu seus objetos spawnados!",
	youFrozeFrom = "Você congelou %s entidades de %s!",
	frozeYourObjects = "congelou seus objetos spawnados!",
	enabledSpawnAbility = "habilitou novamente sua habilidade de spawnar objetos!",
	disabledSpawnAbility = "desabilitou sua habilidade de spawnar objetos!",
	youEnabledSpawnAbility = "Você habilitou a habilidade de %s de spawnar objetos!",
	youDisabledSpawnAbility = "Você desabilitou a habilidade de %s de spawnar objetos!",
	
	resetTheMap = "reiniciou o mapa!",
	noEntNameFound = "Nenhum %s encontrado!",
	noEntitiesFound = "Nenhuma entidade encontrada!",
	noUnfrozenEntsFound = "Nenhuma entidade descongelada encontrada!",
	noUnCollidedEntsFound = "Nenhuma entidade sem colisão encontrada!",
	freezeAllEnts = "%s congelou todas as %s! (%s)",
	noCollideAllEnts = "%s removeu colisão de todas as %s! (%s)",
	removedAllEntName = "%s removeu todas as %s! (%s)",
	entitiesLowCase = "entidades",
	removingOutOfBounds = "Removendo %s fora dos limites",
	
	-- Log do Console
	removedEntitiesFrom = "%s removeu %s entidades de %s!",
	frozeEntitiesFrom = "%s congelou %s entidades de %s!",
	enabledSpawningCapabilities = "%s reabilitou a capacidade de spawnar para %s!",
	disabledSpawningCapabilities = "%s desabilitou a capacidade de spawnar para %s!",
	removingHighCollision = "Removendo %s de alta colisão (%s) de %s!",
	
	-- Exploits
	chatClearKick = "%s foi expulso por usar o exploit ChatClear!",
}

return pt